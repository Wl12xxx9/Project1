// SPDX-License-Identifier: GPL-2.0 OR BSD-3-Clause
/* Copyright(c) 2026  Realtek Corporation
 */

#include <linux/module.h>
#include <linux/pci.h>
#include "pci.h"
#include "pci_old.h"
#include "rtw8812a.h"

static const struct rtw_pci_info rtw_8812ae_pci_info = {
	.chip_info = &rtw8812a_hw_spec,
	.pci_gen = &rtw_pci_gen_old,
};

static const struct pci_device_id rtw_8812ae_id_table[] = {
	{
		PCI_DEVICE(PCI_VENDOR_ID_REALTEK, 0x8812),
		.driver_data = (kernel_ulong_t)&rtw_8812ae_pci_info
	},
	{}
};
MODULE_DEVICE_TABLE(pci, rtw_8812ae_id_table);

static struct pci_driver rtw_8812ae_driver = {
	.name = KBUILD_MODNAME,
	.id_table = rtw_8812ae_id_table,
	.probe = rtw_pci_probe,
	.remove = rtw_pci_remove,
	.driver.pm = &rtw_pm_ops,
	.shutdown = rtw_pci_shutdown,
	.err_handler = &rtw_pci_err_handler,
};
module_pci_driver(rtw_8812ae_driver);

MODULE_AUTHOR("Realtek Corporation");
MODULE_DESCRIPTION("Realtek 802.11ac wireless 8812ae driver");
MODULE_LICENSE("Dual BSD/GPL");
